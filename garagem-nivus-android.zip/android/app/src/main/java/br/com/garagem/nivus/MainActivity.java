package br.com.garagem.nivus;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
