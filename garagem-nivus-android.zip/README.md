# Garagem Nivus (Android)

App de controle do VW Nivus: revisões por km/ano, checklist, alertas, custos, combustível, documentos e backup.
Empacotado com Capacitor; o APK é gerado na nuvem pelo GitHub Actions (não precisa instalar nada no PC).

## Gerar o APK pelo GitHub
1. Crie um repositório novo no GitHub (pode ser privado) e envie **todo o conteúdo desta pasta** (inclusive a pasta oculta `.github`).
2. Abra a aba **Actions** do repositório. O fluxo "Gerar APK" roda sozinho a cada envio (ou clique em *Run workflow*). Leva ~5 a 10 min.
3. Abra a execução concluída, role até **Artifacts** e baixe `garagem-nivus-apk` (zip com o `app-debug.apk`).
4. Passe o APK para o celular e instale (permita "Instalar apps de fontes desconhecidas" quando o Android pedir).

## Compilar no seu computador (opcional)
Requer Node 22+, Android Studio (SDK 36) e JDK 21.
```
npm ci
npx cap sync android
npx cap open android     # Android Studio > Build > Build APK(s)
```

## Atualizar o app
O código do app fica em `www/index.html`. Edite, envie ao GitHub e baixe o novo APK. Instalar por cima mantém os dados (mesmo pacote `br.com.garagem.nivus`), desde que o APK seja assinado com a mesma chave; o APK debug do GitHub pode mudar de chave entre execuções, então **faça backup antes de atualizar**.

## Dados e backup
- Os dados ficam salvos no celular (armazenamento local do app + arquivo `garagem-dados.json` interno).
- Em **Ajustes > Compartilhar backup** gera um JSON e abre a folha de compartilhar (Drive, WhatsApp, e-mail). Para restaurar, use **Importar backup**.
- Desinstalar o app apaga os dados: guarde backups.
- A versão web e a do Android têm dados separados; leve de uma à outra pelo backup.

## Lembretes
Em **Ajustes > Lembretes no celular** ative as notificações (revisões, documentos, resumo semanal às segundas, 9h).

## Limitações
- APK assinado com chave de debug: serve para uso pessoal. Para a Play Store é preciso keystore própria e conta de desenvolvedor (taxa única ~US$ 25).
- Valores de custo e intervalos fora do plano VW são estimativas: confirme no manual/concessionária.
